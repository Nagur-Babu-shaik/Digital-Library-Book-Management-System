package com.nagur.BookManagementSystem.model;

//Making sure the 'Availability Status should be either AVAILABLE or CHECKEDOUT'
public enum AvailabilityStatus {

	   AVAILABLE,
	   CHECKEDOUT
	
}
